let currentQuestions = [];
let currentQuestionIndex = 0;
let score = 0;

async function startQuiz() {
    const numQuestions = document.getElementById('numQuestions').value;
    const category = document.getElementById('category').value;
    const difficulty = document.getElementById('difficulty').value;

    // Construct API URL based on user selections
    let apiUrl = `https://opentdb.com/api.php?amount=${numQuestions}`;
    if (category !== 'any') apiUrl += `&category=${category}`;
    if (difficulty !== 'any') apiUrl += `&difficulty=${difficulty}`;
    apiUrl += '&type=multiple';

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        
        if (data.response_code === 0) {
            currentQuestions = data.results;
            document.querySelector('.setup-container').style.display = 'none';
            document.querySelector('.quiz-container').style.display = 'block';
            displayQuestion();
        } else {
            alert('Error loading questions. Please try different parameters.');
        }
    } catch (error) {
        alert('Error fetching questions. Please try again.');
        console.error('Error:', error);
    }
}

function displayQuestion() {
    if (currentQuestionIndex >= currentQuestions.length) {
        showFinalResult();
        return;
    }

    const question = currentQuestions[currentQuestionIndex];
    // Decode HTML entities in the question and answers
    const decodedQuestion = decodeHTMLEntities(question.question);
    const decodedCorrectAnswer = decodeHTMLEntities(question.correct_answer);
    const decodedIncorrectAnswers = question.incorrect_answers.map(answer => 
        decodeHTMLEntities(answer)
    );

    // Combine and shuffle answers
    const options = [...decodedIncorrectAnswers, decodedCorrectAnswer];
    shuffleArray(options);

    const container = document.getElementById('question-container');
    container.innerHTML = `
        <div class="question-container">
            <h3>Question ${currentQuestionIndex + 1}/${currentQuestions.length}</h3>
            <p>${decodedQuestion}</p>
            <div class="options">
                ${options.map(option => `
                    <div class="option" onclick="checkAnswer('${option.replace(/'/g, "&apos;")}', this)">
                        ${option}
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function checkAnswer(selectedAnswer, element) {
    const question = currentQuestions[currentQuestionIndex];
    const decodedCorrectAnswer = decodeHTMLEntities(question.correct_answer);
    const options = document.querySelectorAll('.option');
    
    // Disable clicking on options after selection
    options.forEach(option => option.style.pointerEvents = 'none');

    if (selectedAnswer === decodedCorrectAnswer) {
        element.classList.add('correct');
        score++;
    } else {
        element.classList.add('incorrect');
        options.forEach(option => {
            if (option.textContent.trim() === decodedCorrectAnswer) {
                option.classList.add('correct');
            }
        });
    }

    // Wait 1.5 seconds before showing next question
    setTimeout(() => {
        currentQuestionIndex++;
        displayQuestion();
    }, 1500);
}

function showFinalResult() {
    const container = document.getElementById('question-container');
    container.innerHTML = '';
    const result = document.getElementById('result');
    const percentage = (score / currentQuestions.length) * 100;
    result.textContent = `Quiz completed! Your score: ${score}/${currentQuestions.length} (${percentage.toFixed(2)}%)`;
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

// Helper function to decode HTML entities
function decodeHTMLEntities(text) {
    const textArea = document.createElement('textarea');
    textArea.innerHTML = text;
    return textArea.value;
} 